SMM Exchange - Minimal ZIP (MVP)
================================

This archive contains a minimal, runnable scaffold for the SMM Exchange project.

How to run (server):
1. cd server
2. npm install
3. copy .env.example to .env and fill values (MONGO_URI, JWT_SECRET, STRIPE keys)
4. npm run dev

How to run (client):
1. cd client
2. npm install
3. npm run dev

Notes:
- Stripe webhook: to test locally use `stripe listen` and set STRIPE_WEBHOOK_SECRET accordingly.
- Paymob endpoints are stubs and need real integration details.

