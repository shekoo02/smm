import React, { useState } from 'react'
import axios from 'axios'
export default function CreateTask(){
  const [form, setForm] = useState({ type: 'follow', platform: 'tiktok', link: '', pricePerAction: 1, totalRequired: 100 })
  const handle = async (e)=>{
    e.preventDefault();
    const token = localStorage.getItem('token');
    await axios.post('/api/tasks', form, { headers: { Authorization: `Bearer ${token}` } });
    alert('Task created');
  }
  return (
    <div className="max-w-3xl mx-auto p-4">
      <h2 className="text-2xl mb-4">Create Task</h2>
      <form onSubmit={handle} className="space-y-3">
        <select value={form.type} onChange={e=>setForm({...form,type:e.target.value})} className="input">
          <option value="follow">Follow</option>
          <option value="like">Like</option>
          <option value="comment">Comment</option>
        </select>
        <input value={form.link} onChange={e=>setForm({...form,link:e.target.value})} placeholder="Profile or post link" className="input" />
        <div className="flex gap-2">
          <input type="number" value={form.pricePerAction} onChange={e=>setForm({...form,pricePerAction:Number(e.target.value)})} className="input" />
          <input type="number" value={form.totalRequired} onChange={e=>setForm({...form,totalRequired:Number(e.target.value)})} className="input" />
        </div>
        <button className="btn">Create</button>
      </form>
    </div>
  )
}
