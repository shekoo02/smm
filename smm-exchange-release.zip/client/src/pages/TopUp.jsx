import React, { useState } from 'react';
import axios from 'axios';
export default function TopUp(){
  const [amount, setAmount] = useState(5);
  const token = localStorage.getItem('token');
  const topUpStripe = async () => {
    const res = await axios.post('/api/payments/stripe/create-checkout-session', { amount }, { headers: { Authorization: `Bearer ${token}` } });
    window.location = res.data.url;
  }
  const topUpPaymob = async ()=> {
    const res = await axios.post('/api/payments/paymob/init', { amount }, { headers: { Authorization: `Bearer ${token}` } });
    window.location = res.data.redirectUrl;
  }
  return (
    <div className="max-w-xl mx-auto p-4">
      <h2 className="text-2xl mb-4">إضافة رصيد</h2>
      <input type="number" value={amount} onChange={e=>setAmount(Number(e.target.value))} className="input" />
      <div className="flex gap-3 mt-3">
        <button className="btn" onClick={topUpStripe}>دفع ببطاقة (Stripe)</button>
        <button className="btn-outline" onClick={topUpPaymob}>دفع (Paymob)</button>
      </div>
    </div>
  )
}
