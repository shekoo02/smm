import React from 'react'
import { Link } from 'react-router-dom'
export default function Home(){
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl mb-4">منصة تبادل التفاعل</h1>
      <p className="mb-4">ابدأ بإنشاء مهام أو شحذ مهاراتك كمنفّذ مهام.</p>
      <div className="flex gap-3">
        <Link to="/create" className="btn">إنشاء مهمة</Link>
        <Link to="/topup" className="btn-outline">إضافة رصيد</Link>
      </div>
    </div>
  )
}
