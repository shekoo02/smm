import React from 'react'
export default function Dashboard(){
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h2 className="text-2xl mb-3">لوحة التحكم</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="card"><h3>الرصيد</h3><p>--- EGP</p></div>
        <div className="card"><h3>مهامي</h3><p>---</p></div>
        <div className="card"><h3>طلبات معلّقة</h3><p>---</p></div>
      </div>
    </div>
  )
}
