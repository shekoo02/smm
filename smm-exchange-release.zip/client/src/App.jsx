import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import Dashboard from './pages/Dashboard'
import CreateTask from './pages/CreateTask'
import TopUp from './pages/TopUp'
export default function App(){
  return (
    <div className="min-h-screen bg-gray-50">
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/dashboard" element={<Dashboard/>} />
        <Route path="/create" element={<CreateTask/>} />
        <Route path="/topup" element={<TopUp/>} />
      </Routes>
    </div>
  )
}
