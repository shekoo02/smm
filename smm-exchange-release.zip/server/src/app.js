const express = require('express');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const taskRoutes = require('./routes/tasks');
const actionRoutes = require('./routes/actions');
const adminRoutes = require('./routes/admin');
const paymentRoutes = require('./routes/payments');
const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || '*' }));
// for stripe webhook we will mount raw body at route level
app.use(express.json());
app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/actions', actionRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/payments', paymentRoutes);
app.get('/', (req, res) => res.json({ ok: true }));
module.exports = app;
