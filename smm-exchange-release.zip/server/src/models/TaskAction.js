const mongoose = require('mongoose');
const actionSchema = new mongoose.Schema({
  task: { type: mongoose.Schema.Types.ObjectId, ref: 'Task' },
  worker: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  proof: { type: String },
  status: { type: String, enum: ['pending','approved','rejected'], default: 'pending' },
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('TaskAction', actionSchema);
