const mongoose = require('mongoose');
const txSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  type: { type: String, enum: ['deposit','withdrawal','earning','fee'] },
  amount: Number,
  meta: Object,
  status: { type: String, enum: ['pending','completed','cancelled'], default: 'completed' },
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Transaction', txSchema);
