const mongoose = require('mongoose');
const taskSchema = new mongoose.Schema({
  buyer: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  type: { type: String, enum: ['follow','like','comment','view'], required: true },
  platform: { type: String, required: true },
  link: { type: String, required: true },
  pricePerAction: { type: Number, required: true },
  totalRequired: { type: Number, required: true },
  completed: { type: Number, default: 0 },
  status: { type: String, enum: ['open','paused','completed','cancelled'], default: 'open' },
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Task', taskSchema);
