const express = require('express');
const multer = require('multer');
const TaskAction = require('../models/TaskAction');
const Task = require('../models/Task');
const auth = require('../middlewares/auth');
const router = express.Router();
const upload = multer({ dest: 'uploads/' });
router.post('/:taskId/submit', auth, upload.single('proof'), async (req, res) => {
  const task = await Task.findById(req.params.taskId);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  const action = new TaskAction({ task: task._id, worker: req.user._id, proof: req.file ? req.file.path : req.body.proof });
  await action.save();
  res.json({ ok: true, action });
});
module.exports = router;
