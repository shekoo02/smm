const express = require('express');
const auth = require('../middlewares/auth');
const role = require('../middlewares/role');
const TaskAction = require('../models/TaskAction');
const Task = require('../models/Task');
const User = require('../models/User');
const router = express.Router();
router.get('/actions/pending', auth, role('admin'), async (req, res) => {
  const pending = await TaskAction.find({ status: 'pending' }).populate('task worker');
  res.json(pending);
});
router.post('/action/:id/approve', auth, role('admin'), async (req, res) => {
  const action = await TaskAction.findById(req.params.id).populate('task worker');
  if (!action) return res.status(404).json({ error: 'Not found' });
  action.status = 'approved';
  await action.save();
  const task = await Task.findById(action.task._id);
  task.completed += 1;
  if (task.completed >= task.totalRequired) task.status = 'completed';
  await task.save();
  const worker = await User.findById(action.worker._id);
  worker.earnings += task.pricePerAction;
  worker.balance += task.pricePerAction;
  await worker.save();
  res.json({ ok: true });
});
module.exports = router;
