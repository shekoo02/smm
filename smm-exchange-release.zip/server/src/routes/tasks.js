const express = require('express');
const Task = require('../models/Task');
const auth = require('../middlewares/auth');
const router = express.Router();
router.post('/', auth, async (req, res) => {
  const { type, platform, link, pricePerAction, totalRequired } = req.body;
  const task = new Task({ buyer: req.user._id, type, platform, link, pricePerAction, totalRequired });
  await task.save();
  res.json(task);
});
router.get('/open', auth, async (req, res) => {
  const tasks = await Task.find({ status: 'open' }).limit(50);
  res.json(tasks);
});
module.exports = router;
