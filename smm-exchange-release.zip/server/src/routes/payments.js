const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const auth = require('../middlewares/auth');
const router = express.Router();
router.post('/stripe/create-checkout-session', auth, async (req, res) => {
  const { amount, currency='usd' } = req.body;
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    mode: 'payment',
    line_items: [{ price_data: { currency, product_data: { name: 'Wallet Top-up' }, unit_amount: Math.round(amount * 100) }, quantity: 1 }],
    success_url: `${process.env.CLIENT_URL}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.CLIENT_URL}/dashboard`,
    metadata: { userId: req.user._id.toString() }
  });
  await Transaction.create({ user: req.user._id, type: 'deposit', amount, status: 'pending', meta: { provider: 'stripe', sessionId: session.id } });
  res.json({ url: session.url });
});
router.post('/stripe/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature error', err);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const userId = session.metadata.userId;
    const amount = session.amount_total / 100;
    const tx = await Transaction.findOneAndUpdate({ 'meta.sessionId': session.id }, { status: 'completed' }, { new: true });
    if (tx) {
      await User.findByIdAndUpdate(userId, { $inc: { balance: amount } });
    }
  }
  res.json({ received: true });
});
router.post('/paymob/init', auth, async (req, res) => {
  const { amount, currency='EGP' } = req.body;
  const fakeOrderId = `paymob_${Date.now()}`;
  await Transaction.create({ user: req.user._id, type: 'deposit', amount, status: 'pending', meta: { provider: 'paymob', orderId: fakeOrderId } });
  res.json({ init: true, orderId: fakeOrderId, redirectUrl: `${process.env.CLIENT_URL}/paymob/return?orderId=${fakeOrderId}` });
});
router.post('/paymob/verify', async (req, res) => {
  const { orderId } = req.body;
  const tx = await Transaction.findOne({ 'meta.orderId': orderId });
  if (!tx) return res.status(404).json({ error: 'Not found' });
  tx.status = 'completed';
  await tx.save();
  await User.findByIdAndUpdate(tx.user, { $inc: { balance: tx.amount } });
  res.json({ ok: true });
});
module.exports = router;
